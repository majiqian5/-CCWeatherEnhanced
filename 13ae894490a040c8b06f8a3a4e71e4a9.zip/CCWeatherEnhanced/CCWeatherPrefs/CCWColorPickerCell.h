//
//  CCWColorPickerCell.h
//  CCWeatherPrefs
//

#import <UIKit/UIKit.h>
#import <Preferences/PSTableCell.h>

@interface CCWColorPickerCell : PSTableCell <UIColorPickerViewControllerDelegate>
@property (nonatomic, strong) UIColor *currentColor;
@property (nonatomic, strong) UIView *colorPreview;
@end
