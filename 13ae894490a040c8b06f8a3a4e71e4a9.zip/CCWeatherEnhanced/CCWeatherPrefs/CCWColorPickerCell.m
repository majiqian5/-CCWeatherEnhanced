//
//  CCWColorPickerCell.m
//  CCWeatherPrefs
//

#import "CCWColorPickerCell.h"
#import <Preferences/PSSpecifier.h>

@implementation CCWColorPickerCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier specifier:(PSSpecifier *)specifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier specifier:specifier];
    if (self) {
        _colorPreview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 28, 28)];
        _colorPreview.layer.cornerRadius = 14;
        _colorPreview.layer.borderWidth = 1.5;
        _colorPreview.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _colorPreview.backgroundColor = [UIColor whiteColor];
        self.accessoryView = _colorPreview;
    }
    return self;
}

- (void)refreshCellContentsWithSpecifier:(PSSpecifier *)specifier {
    [super refreshCellContentsWithSpecifier:specifier];
    
    // 读取当前颜色
    id value = [specifier propertyForKey:@"default"];
    if ([value isKindOfClass:[NSDictionary class]]) {
        NSDictionary *colorDict = (NSDictionary *)value;
        CGFloat r = [colorDict[@"r"] floatValue] / 255.0;
        CGFloat g = [colorDict[@"g"] floatValue] / 255.0;
        CGFloat b = [colorDict[@"b"] floatValue] / 255.0;
        CGFloat a = [colorDict[@"a"] floatValue];
        _currentColor = [UIColor colorWithRed:r green:g blue:b alpha:a];
        _colorPreview.backgroundColor = _currentColor;
    }
}

- (void)didSelect {
    // 弹出颜色选择器
    UIColorPickerViewController *colorPicker = [[UIColorPickerViewController alloc] init];
    colorPicker.delegate = self;
    colorPicker.selectedColor = _currentColor ?: [UIColor whiteColor];
    colorPicker.supportsAlpha = YES;
    colorPicker.title = self.specifier.name;
    
    // 获取当前视图控制器并present
    UIResponder *responder = self;
    while (responder && ![responder isKindOfClass:[UIViewController class]]) {
        responder = [responder nextResponder];
    }
    UIViewController *vc = (UIViewController *)responder;
    if (vc) {
        [vc presentViewController:colorPicker animated:YES completion:nil];
    }
}

#pragma mark - UIColorPickerViewControllerDelegate

- (void)colorPickerViewController:(UIColorPickerViewController *)picker didSelectColor:(UIColor *)color continuously:(BOOL)continuously {
    _currentColor = color;
    _colorPreview.backgroundColor = color;
    
    if (!continuously) {
        // 保存颜色
        CGFloat r, g, b, a;
        [color getRed:&r green:&g blue:&b alpha:&a];
        NSDictionary *colorDict = @{
            @"r": @(r * 255),
            @"g": @(g * 255),
            @"b": @(b * 255),
            @"a": @(a)
        };
        
        // 通过设置控制器保存
        UIResponder *responder = self;
        while (responder && ![responder isKindOfClass:NSClassFromString(@"CCWRootListController")]) {
            responder = [responder nextResponder];
        }
        if (responder) {
            [responder performSelector:@selector(savePreferenceValue:specifier:) withObject:colorDict withObject:self.specifier];
        }
    }
}

- (void)colorPickerViewControllerDidFinish:(UIColorPickerViewController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

@end
