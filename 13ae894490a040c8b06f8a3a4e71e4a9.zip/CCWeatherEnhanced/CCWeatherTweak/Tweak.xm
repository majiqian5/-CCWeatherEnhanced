//
//  Tweak.xm
//  CCWeatherEnhanced - 注入层
//  负责模块注册、偏好监听、全局外观增强
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "../CCWeatherConfig.h"

// 前置声明
@interface CCUIModuleInstance : NSObject
- (id)module;
@end

@interface CCWeatherModule : NSObject
@end

%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    // 初始化偏好监听
    [[NSNotificationCenter defaultCenter] addObserverForName:CCW_NOTIFY_CHANGED
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:^(NSNotification *note) {
        NSLog(@"[CCWeatherEnhanced] 偏好已更新，刷新控制中心");
        // 发送通知让模块刷新
        [[NSNotificationCenter defaultCenter] postNotificationName:@"CCWeatherModuleShouldRefresh" object:nil];
    }];
    
    // 延迟刷新控制中心模块列表，确保模块被系统发现
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"[CCWeatherEnhanced] 刷新控制中心模块列表");
        // 发送控制中心刷新通知
        [[NSNotificationCenter defaultCenter] postNotificationName:@"CCUIModuleRepositoryDidChange" object:nil];
    });
    
    NSLog(@"[CCWeatherEnhanced] 已加载 v2.0.0");
}
%end

// Hook 控制中心模块实例，确保我们的模块正确初始化
%hook CCUIModuleInstance
- (void)setModule:(id)module {
    %orig;
    if ([module isKindOfClass:NSClassFromString(@"CCWeatherModule")]) {
        NSLog(@"[CCWeatherEnhanced] 天气模块已加载");
    }
}
%end

// 增强：Hook CCWeatherModule 的视图加载，应用额外的全局样式
%hook UIView
- (void)didMoveToWindow {
    %orig;
    // 检查是否是我们的模块视图
    if (self.window && [NSStringFromClass([self class]) containsString:@"CCWeather"]) {
        // 确保圆角和裁剪正确
        self.layer.masksToBounds = YES;
    }
}
%end

// 确保偏好变更通知能跨进程传递
%hook NSUserDefaults
- (void)setObject:(id)object forKey:(NSString *)key {
    %orig;
    if ([key isEqualToString:CCW_PREF_DOMAIN]) {
        // 延迟发送通知，确保写入完成
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] postNotificationName:CCW_NOTIFY_CHANGED object:nil];
            // 同时发送 Darwin 通知（跨进程）
            CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                                 (CFStringRef)CCW_NOTIFY_CHANGED,
                                                 NULL, NULL, YES);
        });
    }
}
%end
