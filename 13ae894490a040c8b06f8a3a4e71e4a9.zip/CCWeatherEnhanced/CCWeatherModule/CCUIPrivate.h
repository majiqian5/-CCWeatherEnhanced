//
//  CCUIPrivate.h
//  ControlCenterUIKit 私有协议声明
//  用于弥补 theos 缺少私有头文件的问题
//

#import <UIKit/UIKit.h>

#ifndef CCUIPrivate_h
#define CCUIPrivate_h

// 布局尺寸结构体
typedef struct CCUILayoutSize {
    NSUInteger width;
    NSUInteger height;
} CCUILayoutSize;

NS_INLINE CCUILayoutSize CCUILayoutSizeMake(NSUInteger width, NSUInteger height) {
    CCUILayoutSize size;
    size.width = width;
    size.height = height;
    return size;
}

// 内容视图控制器协议
@protocol CCUIContentModuleContentViewController <NSObject>
@property (nonatomic, readonly) CCUILayoutSize preferredContentSize;
@optional
- (void)willResignActive;
- (void)didBecomeActive;
- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator;
@end

// 模块协议
@protocol CCUIContentModule <NSObject>
@property (nonatomic, readonly) UIViewController<CCUIContentModuleContentViewController> *contentViewController;
@optional
@property (nonatomic, readonly) UIViewController *backgroundViewController;
- (void)setContentViewController:(UIViewController<CCUIContentModuleContentViewController> *)contentViewController;
@end

#endif /* CCUIPrivate_h */
