//
//  CCWeatherModule.m
//

#import "CCWeatherModule.h"
#import "CCWThemeManager.h"

@implementation CCWeatherModule

- (instancetype)init {
    self = [super init];
    if (self) {
        // 初始化主题管理器
        [CCWThemeManager sharedManager];
    }
    return self;
}

#pragma mark - CCUIContentModule

- (UIViewController<CCUIContentModuleContentViewController> *)contentViewController {
    if (!_contentViewController) {
        _contentViewController = [[CCWeatherViewController alloc] init];
    }
    return _contentViewController;
}

- (UIViewController *)backgroundViewController {
    return nil;
}

@end
