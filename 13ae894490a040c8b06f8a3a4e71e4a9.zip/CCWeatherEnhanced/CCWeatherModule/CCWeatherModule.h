//
//  CCWeatherModule.h
//  控制中心模块主类 - 实现 CCUIContentModule 协议
//

#import <UIKit/UIKit.h>
#import "CCUIPrivate.h"
#import "CCWeatherViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCWeatherModule : NSObject <CCUIContentModule>

@property (nonatomic, strong) CCWeatherViewController *contentViewController;

@end

NS_ASSUME_NONNULL_END
