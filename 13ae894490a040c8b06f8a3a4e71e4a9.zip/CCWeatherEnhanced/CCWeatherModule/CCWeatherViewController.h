//
//  CCWeatherViewController.h
//  控制中心天气模块主视图控制器
//

#import <UIKit/UIKit.h>
#import "CCUIPrivate.h"
#import "CCWeatherData.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCWeatherViewController : UIViewController <CCUIContentModuleContentViewController>

@property (nonatomic, strong) CCWeatherData *weatherData;
@property (nonatomic, assign) BOOL expanded;

// 刷新UI
- (void)refreshUI;
- (void)applyTheme;

// 交互动作
- (void)handleSingleTap:(UITapGestureRecognizer *)tap;
- (void)handleDoubleTap:(UITapGestureRecognizer *)tap;
- (void)handleLongPress:(UILongPressGestureRecognizer *)press;
- (void)handleTwoFingerTap:(UITapGestureRecognizer *)tap;

// 展开/收起
- (void)toggleExpanded;

@end

NS_ASSUME_NONNULL_END
