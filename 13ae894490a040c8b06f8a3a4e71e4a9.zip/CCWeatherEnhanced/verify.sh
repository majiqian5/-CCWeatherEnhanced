#!/bin/bash
# 验证 deb 包内所有二进制的架构
# 使用方法：bash verify.sh packages/xxx.deb

if [ -z "$1" ]; then
    echo "用法: bash verify.sh <deb文件路径>"
    echo "示例: bash verify.sh packages/com.axs.ccweatherenhanced_2.0.0_iphoneos-arm64.deb"
    exit 1
fi

DEB_FILE="$1"

if [ ! -f "$DEB_FILE" ]; then
    echo "错误：文件不存在: $DEB_FILE"
    exit 1
fi

echo "========================================="
echo "  架构验证: $DEB_FILE"
echo "========================================="
echo ""

TMP_DIR=$(mktemp -d)
dpkg-deb -x "$DEB_FILE" "$TMP_DIR"

ALL_OK=true
COUNT=0

# 查找所有 Mach-O 二进制文件
while IFS= read -r BIN; do
    COUNT=$((COUNT + 1))
    BASENAME=$(basename "$BIN")
    ARCHS=$(lipo -info "$BIN" 2>/dev/null || echo "无法读取")

    echo "[$COUNT] $BASENAME"
    echo "    路径: ${BIN#$TMP_DIR}"
    echo "    架构: $ARCHS"

    if echo "$ARCHS" | grep -q "arm64e"; then
        echo "    ✅ 包含 arm64e"
    else
        echo "    ❌ 缺少 arm64e（A12+ 设备会无法加载）"
        ALL_OK=false
    fi
    echo ""
done < <(find "$TMP_DIR" -type f \( -name "*.dylib" -o -name "CCWeatherPrefs" -o -name "CCWeatherModule" \))

rm -rf "$TMP_DIR"

echo "========================================="
if [ "$ALL_OK" = true ] && [ "$COUNT" -gt 0 ]; then
    echo "✅ 验证通过：全部 $COUNT 个二进制均包含 arm64 + arm64e"
    exit 0
else
    echo "❌ 验证失败：存在缺少 arm64e 的二进制"
    echo "   原因通常是编译环境缺少 iOS SDK"
    echo "   解决：下载 SDK 到 \$THEOS/sdks/ 后重新编译"
    exit 1
fi
