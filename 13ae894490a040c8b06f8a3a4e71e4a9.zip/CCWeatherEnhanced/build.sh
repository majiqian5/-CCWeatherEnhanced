#!/bin/bash
# 手机端一键编译脚本
# 使用方法：在 NewTerm 中运行 bash build.sh
set -e

echo "========================================="
echo "  CCWeatherEnhanced 一键编译脚本"
echo "========================================="

# 检查 Theos
if [ -z "$THEOS" ]; then
    if [ -d "/opt/theos" ]; then
        export THEOS=/opt/theos
    elif [ -d "$HOME/theos" ]; then
        export THEOS=$HOME/theos
    else
        echo "[错误] 未找到 Theos，请先安装："
        echo "  apt install theos"
        echo "  或从 https://theos.dev 安装"
        exit 1
    fi
fi
echo "[信息] THEOS = $THEOS"
export PATH=$THEOS/bin:$PATH

# 检查依赖
echo "[信息] 检查编译依赖..."
for cmd in clang ldid dpkg-deb make lipo; do
    if ! command -v $cmd &> /dev/null; then
        echo "[错误] 缺少 $cmd，请运行：apt install $cmd"
        exit 1
    fi
done

# 检查 SDK（关键：确保支持 arm64e）
echo "[信息] 检查 iOS SDK..."
SDK_COUNT=$(ls -d $THEOS/sdks/iPhoneOS*.sdk 2>/dev/null | wc -l)
if [ "$SDK_COUNT" -eq 0 ]; then
    echo "[警告] 未找到 iPhoneOS.sdk，arm64e 编译可能失败！"
    echo "  请下载 SDK 到 $THEOS/sdks/ 目录"
    echo "  下载地址：https://github.com/theos/sdks"
    read -p "是否继续？(y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo "[信息] 找到 $SDK_COUNT 个 SDK"
    ls -d $THEOS/sdks/iPhoneOS*.sdk
fi

# 进入脚本所在目录
cd "$(dirname "$0")"

echo "[信息] 清理旧编译..."
make clean > /dev/null 2>&1 || true

echo "[信息] 开始编译 (arm64 + arm64e)..."
if make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=rootless; then
    echo ""
    echo "========================================="
    echo "  编译成功！"
    echo "========================================="
    echo ""

    DEB_FILE=$(ls -t packages/*.deb 2>/dev/null | head -1)
    if [ -n "$DEB_FILE" ]; then
        echo "deb 文件：$DEB_FILE"
        echo ""

        # 架构验证（关键步骤）
        echo "=== 架构验证 ==="
        TMP_DIR=$(mktemp -d)
        dpkg-deb -x "$DEB_FILE" "$TMP_DIR"

        PREFS_BIN=$(find "$TMP_DIR" -name "CCWeatherPrefs" -type f | head -1)
        MODULE_BIN=$(find "$TMP_DIR" -name "CCWeatherModule" -type f | head -1)
        TWEAK_BIN=$(find "$TMP_DIR" -name "CCWeatherTweak.dylib" -type f | head -1)

        ALL_OK=true

        if [ -n "$PREFS_BIN" ]; then
            ARCHS=$(lipo -info "$PREFS_BIN" 2>/dev/null)
            echo "设置插件: $ARCHS"
            if echo "$ARCHS" | grep -q "arm64e"; then
                echo "  ✅ 包含 arm64e"
            else
                echo "  ❌ 缺少 arm64e！"
                ALL_OK=false
            fi
        fi

        if [ -n "$MODULE_BIN" ]; then
            ARCHS=$(lipo -info "$MODULE_BIN" 2>/dev/null)
            echo "控制中心模块: $ARCHS"
            if echo "$ARCHS" | grep -q "arm64e"; then
                echo "  ✅ 包含 arm64e"
            else
                echo "  ❌ 缺少 arm64e！"
                ALL_OK=false
            fi
        fi

        if [ -n "$TWEAK_BIN" ]; then
            ARCHS=$(lipo -info "$TWEAK_BIN" 2>/dev/null)
            echo "注入 Tweak: $ARCHS"
            if echo "$ARCHS" | grep -q "arm64e"; then
                echo "  ✅ 包含 arm64e"
            else
                echo "  ❌ 缺少 arm64e！"
                ALL_OK=false
            fi
        fi

        rm -rf "$TMP_DIR"
        echo ""

        if [ "$ALL_OK" = true ]; then
            echo "✅ 架构验证通过：所有二进制均包含 arm64 + arm64e"
        else
            echo "❌ 架构验证失败！部分二进制缺少 arm64e，安装后会导致设置页面打不开。"
            echo "  请检查 SDK 是否正确安装。"
            read -p "是否仍要继续安装？(y/N) " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                exit 1
            fi
        fi

        echo ""
        echo "安装命令："
        echo "  dpkg -i $DEB_FILE"
        echo "  killall -9 SpringBoard"
        echo ""
        read -p "是否现在安装？(y/N) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            echo "[信息] 正在安装..."
            dpkg -i "$DEB_FILE"
            echo "[信息] 重启 SpringBoard..."
            killall -9 SpringBoard
            echo "[完成] 已安装并重启！"
        fi
    fi
else
    echo ""
    echo "[错误] 编译失败，请检查上面的错误信息。"
    exit 1
fi
