#ifndef NSEC_PER_SEC
#define NSEC_PER_SEC 1000000000ULL
#endif
//
//  CCWeatherManager.m
//

#import "CCWeatherManager.h"
#import "CCWThemeManager.h"

@interface CCWeatherManager ()
@property (nonatomic, strong) NSTimer *refreshTimer;
@property (nonatomic, assign) BOOL isFetching;
@end

@implementation CCWeatherManager

+ (instancetype)sharedManager {
    static CCWeatherManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[CCWeatherManager alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.locationManager = [[CLLocationManager alloc] init];
        self.locationManager.delegate = self;
        self.locationManager.desiredAccuracy = kCLLocationAccuracyThreeKilometers;
        self.currentCoordinate = CLLocationCoordinate2DMake(39.9042, 116.4074); // 默认北京
        self.currentCity = @"北京";
    }
    return self;
}

#pragma mark - 公共方法

- (void)refreshWeatherWithCompletion:(CCWeatherCompletion)completion {
    if (self.isFetching) {
        if (completion) completion(nil, [NSError errorWithDomain:@"CCWeather" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"正在获取中"}]);
        return;
    }
    self.isFetching = YES;

    CCWThemeManager *prefs = [CCWThemeManager sharedManager];

    void (^fetchWeather)(CLLocationCoordinate2D) = ^(CLLocationCoordinate2D coord) {
        [self fetchWeatherFromAPI:coord completion:^(CCWeatherData *data, NSError *error) {
            self.isFetching = NO;
            if (data) {
                self.currentData = data;
                [[NSNotificationCenter defaultCenter] postNotificationName:@"CCWeatherDataUpdated" object:data];
            }
            if (completion) completion(data, error);
        }];
    };

    if (prefs.autoLocation) {
        [self.locationManager requestWhenInUseAuthorization];
        [self.locationManager requestLocation];
        // 短暂等待定位结果，超时用上次坐标
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            fetchWeather(self.currentCoordinate);
        });
    } else {
        if (prefs.customLatitude != 0 && prefs.customLongitude != 0) {
            self.currentCoordinate = CLLocationCoordinate2DMake(prefs.customLatitude, prefs.customLongitude);
        }
        self.currentCity = prefs.customCity.length ? prefs.customCity : self.currentCity;
        fetchWeather(self.currentCoordinate);
    }
}

- (void)fetchWeatherFromAPI:(CLLocationCoordinate2D)coord completion:(CCWeatherCompletion)completion {
    // 使用 Open-Meteo 免费 API（无需 key）
    NSString *urlStr = [NSString stringWithFormat:
        @"https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,relative_humidity_2m,weather_code,precipitation_probability&hourly=temperature_2m,weather_code,precipitation_probability&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1",
        coord.latitude, coord.longitude];

    NSURL *url = [NSURL URLWithString:urlStr];
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error || !data) {
                if (completion) completion(nil, error ?: [NSError errorWithDomain:@"CCWeather" code:-2 userInfo:@{NSLocalizedDescriptionKey:@"无数据"}]);
                return;
            }
            NSError *jsonError;
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
            if (jsonError) {
                if (completion) completion(nil, jsonError);
                return;
            }
            CCWeatherData *weatherData = [self parseWeatherJSON:json];
            if (completion) completion(weatherData, nil);
        });
    }];
    [task resume];
}

- (CCWeatherData *)parseWeatherJSON:(NSDictionary *)json {
    CCWeatherData *data = [[CCWeatherData alloc] init];
    data.city = self.currentCity;
    data.updateTime = [NSDate date];

    NSDictionary *current = json[@"current"];
    if (current) {
        data.currentTemp = [current[@"temperature_2m"] integerValue];
        NSInteger code = [current[@"weather_code"] integerValue];
        data.condition = [self conditionFromCode:code];
        data.iconName = [self iconNameFromCode:code];
        data.precipitation = [current[@"precipitation_probability"] integerValue];
    }

    NSDictionary *daily = json[@"daily"];
    if (daily) {
        NSArray *maxArr = daily[@"temperature_2m_max"];
        NSArray *minArr = daily[@"temperature_2m_min"];
        if (maxArr.count > 0) data.highTemp = [maxArr[0] integerValue];
        if (minArr.count > 0) data.lowTemp = [minArr[0] integerValue];
    }

    // 小时预报
    NSDictionary *hourly = json[@"hourly"];
    if (hourly) {
        NSArray *times = hourly[@"time"];
        NSArray *temps = hourly[@"temperature_2m"];
        NSArray *codes = hourly[@"weather_code"];
        NSArray *precips = hourly[@"precipitation_probability"];

        NSMutableArray *forecasts = [NSMutableArray array];
        NSCalendar *cal = [NSCalendar currentCalendar];
        NSInteger currentHour = [cal component:NSCalendarUnitHour fromDate:[NSDate date]];

        for (NSInteger i = 0; i < MIN(24, times.count); i++) {
            NSString *timeStr = times[i];
            NSInteger hour = 0;
            // 解析 "2024-01-01T14:00"
            NSArray *parts = [timeStr componentsSeparatedByString:@"T"];
            if (parts.count > 1) {
                NSString *hm = parts[1];
                NSArray *hmp = [hm componentsSeparatedByString:@":"];
                if (hmp.count > 0) hour = [hmp[0] integerValue];
            }
            // 只取未来24小时
            if (hour < currentHour && i < currentHour) continue;

            CCWHourlyForecast *f = [[CCWHourlyForecast alloc] init];
            f.time = [NSString stringWithFormat:@"%02ld:00", (long)hour];
            f.temperature = [temps[i] integerValue];
            NSInteger code = [codes[i] integerValue];
            f.condition = [self conditionFromCode:code];
            f.iconName = [self iconNameFromCode:code];
            f.precipitation = [precips[i] integerValue];
            [forecasts addObject:f];
            if (forecasts.count >= 24) break;
        }
        data.hourlyForecasts = forecasts;
    }

    return data;
}

#pragma mark - WMO Weather Code 映射

- (NSString *)conditionFromCode:(NSInteger)code {
    NSDictionary *map = @{
        @0: @"晴朗", @1: @"大部晴朗", @2: @"多云", @3: @"阴天",
        @45: @"雾", @48: @"雾凇", @51: @"小毛毛雨", @53: @"毛毛雨",
        @55: @"大毛毛雨", @56: @"冻毛毛雨", @57: @"强冻毛毛雨",
        @61: @"小雨", @63: @"中雨", @65: @"大雨", @66: @"冻雨",
        @67: @"强冻雨", @71: @"小雪", @73: @"中雪", @75: @"大雪",
        @77: @"雪粒", @80: @"阵雨", @81: @"中阵雨", @82: @"强阵雨",
        @85: @"阵雪", @86: @"强阵雪", @95: @"雷阵雨", @96: @"雷阵雨伴冰雹",
        @99: @"强雷阵雨伴冰雹"
    };
    return map[@(code)] ?: @"未知";
}

- (NSString *)iconNameFromCode:(NSInteger)code {
    BOOL isDay = YES; // 简化处理
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSInteger hour = [cal component:NSCalendarUnitHour fromDate:[NSDate date]];
    isDay = (hour >= 6 && hour < 18);

    if (code == 0) return isDay ? @"晴天-白天" : @"晴天-夜间";
    if (code <= 2) return isDay ? @"多云-白天" : @"多云-夜间";
    if (code == 3) return @"阴天";
    if (code == 45 || code == 48) return @"雾";
    if (code >= 51 && code <= 57) return isDay ? @"小雨-白天" : @"小雨-夜间";
    if (code >= 61 && code <= 67) {
        if (code >= 65) return @"大雨";
        if (code == 66 || code == 67) return @"雨夹雪";
        return @"中雨";
    }
    if (code >= 71 && code <= 77) {
        if (code >= 75) return @"大雪";
        return isDay ? @"小雪-白天" : @"小雪-夜间";
    }
    if (code >= 80 && code <= 82) return code >= 82 ? @"暴雨" : @"中雨";
    if (code >= 85 && code <= 86) return @"大雪";
    if (code >= 95) return @"雷阵雨";
    return @"阴天";
}

+ (NSString *)iconNameForCondition:(NSString *)condition isDay:(BOOL)isDay {
    if ([condition containsString:@"晴"]) return isDay ? @"晴天-白天" : @"晴天-夜间";
    if ([condition containsString:@"多云"]) return isDay ? @"多云-白天" : @"多云-夜间";
    if ([condition containsString:@"阴"]) return @"阴天";
    if ([condition containsString:@"雾"]) return @"雾";
    if ([condition containsString:@"雪"]) return isDay ? @"小雪-白天" : @"小雪-夜间";
    if ([condition containsString:@"雷"]) return @"雷阵雨";
    if ([condition containsString:@"雨"]) return isDay ? @"小雨-白天" : @"小雨-夜间";
    return @"阴天";
}

#pragma mark - 定时刷新

- (void)startAutoRefreshWithInterval:(NSInteger)minutes {
    [self stopAutoRefresh];
    if (minutes <= 0) return;
    self.refreshTimer = [NSTimer scheduledTimerWithTimeInterval:minutes * 60 repeats:YES block:^(NSTimer * _Nonnull timer) {
        [self refreshWeatherWithCompletion:nil];
    }];
}

- (void)stopAutoRefresh {
    [self.refreshTimer invalidate];
    self.refreshTimer = nil;
}

#pragma mark - 温度工具

+ (NSInteger)convertCelsius:(NSInteger)c toUnit:(NSInteger)unit {
    if (unit == 1) return (NSInteger)(c * 9.0 / 5.0 + 32);
    return c;
}

+ (NSString *)temperatureString:(NSInteger)temp unit:(NSInteger)unit {
    NSInteger t = [self convertCelsius:temp toUnit:unit];
    return [NSString stringWithFormat:@"%ld°", (long)t];
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    CLLocation *loc = locations.lastObject;
    if (loc) {
        self.currentCoordinate = loc.coordinate;
        // 反向地理编码获取城市名
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        [geocoder reverseGeocodeLocation:loc completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            if (placemarks.count > 0) {
                CLPlacemark *pm = placemarks[0];
                self.currentCity = pm.locality ?: pm.administrativeArea ?: @"未知";
            }
        }];
    }
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    NSLog(@"[CCWeather] 定位失败: %@", error.localizedDescription);
}

@end
