//
//  CCWRootListController.mm
//

#import "CCWRootListController.h"
#import <UIKit/UIKit.h>

@implementation CCWRootListController {
    PSSpecifier *_currentColorSpecifier;
}

- (NSArray *)specifiers {
    if (!_specifiers) {
        NSMutableArray *specs = [NSMutableArray array];

        // ===== 外观 =====
        [specs addObject:[self groupSpecifierWithName:@"外观"]];

        [specs addObject:[self themeSpecifier]];
        [specs addObject:[self backgroundStyleSpecifier]];
        [specs addObject:[self sliderSpecifierWithName:@"背景透明度" key:kCCWModuleAlpha min:0.2 max:1.0 default:0.85]];
        [specs addObject:[self sliderSpecifierWithName:@"圆角大小" key:kCCWCornerRadius min:0 max:40 default:16]];
        [specs addObject:[self switchSpecifierWithName:@"显示边框" key:kCCWBorderEnabled default:NO]];
        [specs addObject:[self sliderSpecifierWithName:@"边框粗细" key:kCCWBorderWidth min:0 max:5 default:1]];
        [specs addObject:[self colorSpecifierWithName:@"边框颜色" key:kCCWBorderColor defaultColor:[UIColor whiteColor]]];
        [specs addObject:[self switchSpecifierWithName:@"阴影效果" key:kCCWShadowEnabled default:NO]];
        [specs addObject:[self sliderSpecifierWithName:@"阴影半径" key:kCCWShadowRadius min:0 max:20 default:8]];
        [specs addObject:[self sliderSpecifierWithName:@"阴影透明度" key:kCCWShadowOpacity min:0 max:1 default:0.3]];

        // ===== 文字 =====
        [specs addObject:[self groupSpecifierWithName:@"文字"]];

        [specs addObject:[self sliderSpecifierWithName:@"天气图标大小" key:kCCWWeatherIconSize min:30 max:120 default:50]];
        [specs addObject:[self sliderSpecifierWithName:@"温度字体大小" key:kCCWTempFontSize min:20 max:100 default:48]];
        [specs addObject:[self sliderSpecifierWithName:@"城市字体大小" key:kCCWCityFontSize min:12 max:40 default:16]];
        [specs addObject:[self sliderSpecifierWithName:@"小时预报字体大小" key:kCCWHourlyFontSize min:10 max:30 default:12]];

        [specs addObject:[self colorSpecifierWithName:@"温度颜色" key:kCCWTempColor defaultColor:[UIColor whiteColor]]];
        [specs addObject:[self colorSpecifierWithName:@"城市颜色" key:kCCWCityColor defaultColor:[UIColor whiteColor]]];
        [specs addObject:[self colorSpecifierWithName:@"天气状态颜色" key:kCCWStatusColor defaultColor:[UIColor whiteColor]]];
        [specs addObject:[self colorSpecifierWithName:@"小时预报颜色" key:kCCWHourlyColor defaultColor:[UIColor whiteColor]]];

        [specs addObject:[self switchSpecifierWithName:@"彩虹渐变文字" key:kCCWRainbowEnabled default:NO]];
        [specs addObject:[self switchSpecifierWithName:@"彩虹动态流动" key:kCCWRainbowAnimated default:NO]];
        [specs addObject:[self sliderSpecifierWithName:@"彩虹动画速度" key:kCCWRainbowSpeed min:0.1 max:5.0 default:1.0]];
        [specs addObject:[self gradientDirectionSpecifier]];

        // ===== 布局 =====
        [specs addObject:[self groupSpecifierWithName:@"布局"]];

        [specs addObject:[self moduleSizeSpecifier]];
        [specs addObject:[self switchSpecifierWithName:@"动态尺寸模式" key:kCCWDynamicSize default:NO]];
        [specs addObject:[self sliderSpecifierWithName:@"内容间距" key:kCCWContentSpacing min:0 max:20 default:8]];
        [specs addObject:[self alignmentSpecifier]];

        // ===== 天气 =====
        [specs addObject:[self groupSpecifierWithName:@"天气"]];

        [specs addObject:[self switchSpecifierWithName:@"显示最高/最低温" key:kCCWShowHighLow default:YES]];
        [specs addObject:[self switchSpecifierWithName:@"显示天气状况" key:kCCWShowCondition default:YES]];
        [specs addObject:[self switchSpecifierWithName:@"显示降水概率" key:kCCWShowPrecipitation default:YES]];
        [specs addObject:[self switchSpecifierWithName:@"显示城市" key:kCCWShowCity default:YES]];
        [specs addObject:[self switchSpecifierWithName:@"显示小时预报" key:kCCWShowHourly default:YES]];
        [specs addObject:[self switchSpecifierWithName:@"24小时滚动预报" key:kCCWShow24Hour default:NO]];
        [specs addObject:[self tempUnitSpecifier]];
        [specs addObject:[self switchSpecifierWithName:@"自动定位" key:kCCWAutoLocation default:YES]];
        [specs addObject:[self textFieldSpecifierWithName:@"自定义城市" key:kCCWCustomCity placeholder:@"如：上海"]];
        [specs addObject:[self refreshIntervalSpecifier]];

        // ===== 交互 =====
        [specs addObject:[self groupSpecifierWithName:@"交互"]];

        [specs addObject:[self tapActionSpecifierWithName:@"单击动作" key:kCCWSingleTapAction default:0]];
        [specs addObject:[self tapActionSpecifierWithName:@"双击动作" key:kCCWDoubleTapAction default:1]];
        [specs addObject:[self tapActionSpecifierWithName:@"长按动作" key:kCCWLongPressAction default:2]];
        [specs addObject:[self tapActionSpecifierWithName:@"双指点击动作" key:kCCWTwoFingerTapAction default:3]];

        // ===== 高级 =====
        [specs addObject:[self groupSpecifierWithName:@"高级"]];

        [specs addObject:[self switchSpecifierWithName:@"启用动画" key:kCCWAnimationEnabled default:YES]];
        [specs addObject:[self switchSpecifierWithName:@"调试日志" key:kCCWDebugLog default:NO]];
        [specs addObject:[self buttonSpecifierWithName:@"恢复默认设置" action:@selector(resetSettings:)]];
        [specs addObject:[self buttonSpecifierWithName:@"应用并刷新" action:@selector(sendTestNotification:)]];

        _specifiers = specs;
    }
    return _specifiers;
}

#pragma mark - Specifier 构造方法

- (PSSpecifier *)groupSpecifierWithName:(NSString *)name {
    return [PSSpecifier groupSpecifierWithName:name];
}

- (PSSpecifier *)switchSpecifierWithName:(NSString *)name key:(NSString *)key default:(BOOL)def {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name
                                                   target:self
                                                      set:@selector(savePreferenceValue:specifier:)
                                                      get:@selector(readPreferenceValue:)
                                                   detail:nil
                                                     cell:PSSwitchCell
                                                     edit:nil];
    [s setProperty:key forKey:@"key"];
    [s setProperty:@(def) forKey:@"default"];
    return s;
}

- (PSSpecifier *)sliderSpecifierWithName:(NSString *)name key:(NSString *)key min:(CGFloat)min max:(CGFloat)max default:(CGFloat)def {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name
                                                   target:self
                                                      set:@selector(savePreferenceValue:specifier:)
                                                      get:@selector(readPreferenceValue:)
                                                   detail:nil
                                                     cell:PSSliderCell
                                                     edit:nil];
    [s setProperty:key forKey:@"key"];
    [s setProperty:@(min) forKey:@"min"];
    [s setProperty:@(max) forKey:@"max"];
    [s setProperty:@(def) forKey:@"default"];
    return s;
}

- (PSSpecifier *)textFieldSpecifierWithName:(NSString *)name key:(NSString *)key placeholder:(NSString *)placeholder {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name
                                                   target:self
                                                      set:@selector(savePreferenceValue:specifier:)
                                                      get:@selector(readPreferenceValue:)
                                                   detail:nil
                                                     cell:PSEditTextCell
                                                     edit:nil];
    [s setProperty:key forKey:@"key"];
    [s setProperty:placeholder forKey:@"placeholder"];
    [s setProperty:@"" forKey:@"default"];
    return s;
}

- (PSSpecifier *)buttonSpecifierWithName:(NSString *)name action:(SEL)action {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name
                                                   target:self
                                                      set:NULL
                                                      get:NULL
                                                   detail:nil
                                                     cell:PSButtonCell
                                                     edit:nil];
    [s setProperty:NSStringFromSelector(action) forKey:@"action"];
    return s;
}

- (PSSpecifier *)colorSpecifierWithName:(NSString *)name key:(NSString *)key defaultColor:(UIColor *)color {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name
                                                   target:self
                                                      set:NULL
                                                      get:NULL
                                                   detail:nil
                                                     cell:PSLinkCell
                                                     edit:nil];
    [s setProperty:key forKey:@"key"];
    [s setProperty:@YES forKey:@"isColorPicker"];
    CGFloat r,g,b,a;
    [color getRed:&r green:&g blue:&b alpha:&a];
    [s setProperty:@{@"r":@(r*255), @"g":@(g*255), @"b":@(b*255), @"a":@(a)} forKey:@"default"];
    return s;
}

#pragma mark - 颜色选择器

- (void)showColorPicker:(PSSpecifier *)specifier {
    _currentColorSpecifier = specifier;

    UIColorPickerViewController *picker = [[UIColorPickerViewController alloc] init];
    picker.delegate = self;
    picker.supportsAlpha = YES;

    // 读取当前颜色
    NSString *key = [specifier propertyForKey:@"key"];
    NSDictionary *prefs = [self prefsDict];
    NSDictionary *colorDict = prefs[key] ?: [specifier propertyForKey:@"default"];
    if (colorDict) {
        CGFloat r = [colorDict[@"r"] floatValue] / 255.0;
        CGFloat g = [colorDict[@"g"] floatValue] / 255.0;
        CGFloat b = [colorDict[@"b"] floatValue] / 255.0;
        CGFloat a = [colorDict[@"a"] floatValue];
        picker.selectedColor = [UIColor colorWithRed:r green:g blue:b alpha:a];
    }

    [self presentViewController:picker animated:YES completion:nil];
}

- (void)colorPickerViewControllerDidSelectColor:(UIColorPickerViewController *)viewController {
    if (!_currentColorSpecifier) return;

    UIColor *color = viewController.selectedColor;
    CGFloat r, g, b, a;
    [color getRed:&r green:&g blue:&b alpha:&a];
    NSDictionary *colorDict = @{@"r":@(r*255), @"g":@(g*255), @"b":@(b*255), @"a":@(a)};

    [self savePreferenceValue:colorDict specifier:_currentColorSpecifier];
}

- (void)colorPickerViewControllerDidFinish:(UIColorPickerViewController *)viewController {
    _currentColorSpecifier = nil;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    PSSpecifier *specifier = [self specifierAtIndexPath:indexPath];
    if ([[specifier propertyForKey:@"isColorPicker"] boolValue]) {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        [self showColorPicker:specifier];
        return;
    }
    [super tableView:tableView didSelectRowAtIndexPath:indexPath];
}

- (PSSpecifier *)themeSpecifier {
    NSArray *titles = @[@"跟随系统", @"深色", @"浅色", @"海洋蓝", @"日落橙", @"森林绿", @"梦幻紫", @"黑白极简"];
    NSArray *values = @[@0, @1, @2, @3, @4, @5, @6, @7];
    return [self segmentedSpecifierWithName:@"主题" key:kCCWThemeIndex titles:titles values:values default:0];
}

- (PSSpecifier *)backgroundStyleSpecifier {
    NSArray *titles = @[@"毛玻璃", @"半透明", @"实色"];
    NSArray *values = @[@0, @1, @2];
    return [self segmentedSpecifierWithName:@"背景样式" key:kCCWBackgroundStyle titles:titles values:values default:0];
}

- (PSSpecifier *)moduleSizeSpecifier {
    NSArray *titles = @[@"小 2×2", @"横向 4×2", @"大 4×4"];
    NSArray *values = @[@0, @1, @2];
    return [self segmentedSpecifierWithName:@"模块大小" key:kCCWModuleSize titles:titles values:values default:0];
}

- (PSSpecifier *)alignmentSpecifier {
    NSArray *titles = @[@"左对齐", @"居中", @"右对齐"];
    NSArray *values = @[@0, @1, @2];
    return [self segmentedSpecifierWithName:@"内容对齐" key:kCCWContentAlignment titles:titles values:values default:1];
}

- (PSSpecifier *)gradientDirectionSpecifier {
    NSArray *titles = @[@"水平", @"垂直", @"对角"];
    NSArray *values = @[@0, @1, @2];
    return [self segmentedSpecifierWithName:@"渐变方向" key:kCCWGradientDirection titles:titles values:values default:0];
}

- (PSSpecifier *)tempUnitSpecifier {
    NSArray *titles = @[@"摄氏 °C", @"华氏 °F"];
    NSArray *values = @[@0, @1];
    return [self segmentedSpecifierWithName:@"温度单位" key:kCCWTempUnit titles:titles values:values default:0];
}

- (PSSpecifier *)refreshIntervalSpecifier {
    NSArray *titles = @[@"5分钟", @"15分钟", @"30分钟", @"1小时", @"不自动"];
    NSArray *values = @[@5, @15, @30, @60, @0];
    return [self segmentedSpecifierWithName:@"自动刷新间隔" key:kCCWRefreshInterval titles:titles values:values default:15];
}

- (PSSpecifier *)tapActionSpecifierWithName:(NSString *)name key:(NSString *)key default:(NSInteger)def {
    NSArray *titles = @[@"展开/收起", @"刷新天气", @"打开设置", @"切换主题", @"无动作"];
    NSArray *values = @[@0, @1, @2, @3, @4];
    return [self segmentedSpecifierWithName:name key:key titles:titles values:values default:def];
}

- (PSSpecifier *)segmentedSpecifierWithName:(NSString *)name key:(NSString *)key titles:(NSArray *)titles values:(NSArray *)values default:(NSInteger)def {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name
                                                   target:self
                                                      set:@selector(savePreferenceValue:specifier:)
                                                      get:@selector(readPreferenceValue:)
                                                   detail:nil
                                                     cell:PSSegmentCell
                                                     edit:nil];
    [s setProperty:key forKey:@"key"];
    [s setProperty:titles forKey:@"titles"];
    [s setProperty:values forKey:@"values"];
    [s setProperty:@(def) forKey:@"default"];
    return s;
}

#pragma mark - 偏好读写

- (NSDictionary *)prefsDict {
    return [[NSUserDefaults standardUserDefaults] dictionaryForKey:CCW_PREF_DOMAIN] ?: @{};
}

- (void)savePreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if (!key) return;

    NSMutableDictionary *prefs = [NSMutableDictionary dictionaryWithDictionary:[self prefsDict]];
    prefs[key] = value;
    [[NSUserDefaults standardUserDefaults] setObject:prefs forKey:CCW_PREF_DOMAIN];
    [[NSUserDefaults standardUserDefaults] synchronize];

    // 发送变更通知
    [[NSNotificationCenter defaultCenter] postNotificationName:CCW_NOTIFY_CHANGED object:nil];
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         (CFStringRef)CCW_NOTIFY_CHANGED,
                                         NULL, NULL, YES);
}

- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    id defaultValue = [specifier propertyForKey:@"default"];
    if (!key) return defaultValue;

    NSDictionary *prefs = [self prefsDict];
    id value = prefs[key];
    return value ?: defaultValue;
}

#pragma mark - 按钮动作

- (void)resetSettings:(PSSpecifier *)specifier {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"恢复默认"
                                                                   message:@"确定要恢复所有设置为默认值吗？"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:CCW_PREF_DOMAIN];
        [[NSUserDefaults standardUserDefaults] synchronize];
        _specifiers = nil;
        [self reloadSpecifiers];
        [[NSNotificationCenter defaultCenter] postNotificationName:CCW_NOTIFY_CHANGED object:nil];
        CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                             (CFStringRef)CCW_NOTIFY_CHANGED,
                                             NULL, NULL, YES);
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)sendTestNotification:(PSSpecifier *)specifier {
    [[NSNotificationCenter defaultCenter] postNotificationName:CCW_NOTIFY_CHANGED object:nil];
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         (CFStringRef)CCW_NOTIFY_CHANGED,
                                         NULL, NULL, YES);

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"已应用"
                                                                   message:@"设置已应用到控制中心"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - 生命周期

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"控制中心天气增强版";
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadSpecifiers];
}

@end
