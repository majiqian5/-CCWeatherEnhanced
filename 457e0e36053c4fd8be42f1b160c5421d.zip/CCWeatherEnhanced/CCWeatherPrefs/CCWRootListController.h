//
//  CCWRootListController.h
//  设置插件主控制器
//

#import <Preferences/Preferences.h>
#import <UIKit/UIKit.h>
#import "../CCWeatherConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCWRootListController : PSListController <UIColorPickerViewControllerDelegate>

// 保存偏好
- (void)savePreferenceValue:(id)value specifier:(PSSpecifier *)specifier;
- (id)readPreferenceValue:(PSSpecifier *)specifier;

// 恢复默认
- (void)resetSettings:(PSSpecifier *)specifier;

// 测试通知
- (void)sendTestNotification:(PSSpecifier *)specifier;

// 颜色选择器
- (void)showColorPicker:(PSSpecifier *)specifier;

@end

NS_ASSUME_NONNULL_END
