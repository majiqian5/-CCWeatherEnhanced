//
//  CCWeatherModule.h
//  控制中心模块主类 - 实现 CCUIContentModule 协议
//

#import <UIKit/UIKit.h>
#import <ControlCenterUI/CCUIContentModule.h>
#import "CCWeatherViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCWeatherModule : NSObject <CCUIContentModule>

@property (nonatomic, readonly) UIViewController<CCUIContentModuleContentViewController> *contentViewController;

@end

NS_ASSUME_NONNULL_END
