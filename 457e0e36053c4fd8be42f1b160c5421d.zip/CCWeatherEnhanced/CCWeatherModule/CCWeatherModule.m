//
//  CCWeatherModule.m
//

#import "CCWeatherModule.h"

@implementation CCWeatherModule {
    CCWeatherViewController *_contentVC;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        NSLog(@"[CCWeatherEnhanced] Module 初始化");
    }
    return self;
}

#pragma mark - CCUIContentModule

- (UIViewController<CCUIContentModuleContentViewController> *)contentViewController {
    if (!_contentVC) {
        _contentVC = [[CCWeatherViewController alloc] init];
    }
    return _contentVC;
}

- (UIViewController *)backgroundViewController {
    return nil;
}

- (void)setContentModuleRunning:(BOOL)running {
    if (running) {
        NSLog(@"[CCWeatherEnhanced] 模块开始运行");
        [NSNotificationCenter.defaultCenter postNotificationName:@"CCWeatherModuleDidStart" object:nil];
    }
}

- (void)dismissControlCenterAnimated:(BOOL)animated {
    NSLog(@"[CCWeatherEnhanced] 控制中心关闭");
}

@end
