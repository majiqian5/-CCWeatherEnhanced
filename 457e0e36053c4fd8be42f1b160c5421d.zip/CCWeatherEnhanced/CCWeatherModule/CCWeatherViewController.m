//
//  CCWeatherViewController.m
//

#import "CCWeatherViewController.h"
#import "CCWThemeManager.h"
#import "CCWRainbowLabel.h"
#import "CCWeatherManager.h"
#import "CCWeatherConfig.h"

@interface CCWeatherViewController () <UIScrollViewDelegate>
@property (nonatomic, strong) UIView *containerView;
@property (nonatomic, strong) UIImageView *weatherIcon;
@property (nonatomic, strong) CCWRainbowLabel *tempLabel;
@property (nonatomic, strong) CCWRainbowLabel *cityLabel;
@property (nonatomic, strong) CCWRainbowLabel *conditionLabel;
@property (nonatomic, strong) CCWRainbowLabel *highLowLabel;
@property (nonatomic, strong) CCWRainbowLabel *precipLabel;
@property (nonatomic, strong) UIScrollView *hourlyScrollView;
@property (nonatomic, strong) UIStackView *hourlyStackView;
@property (nonatomic, strong) UIActivityIndicatorView *loadingIndicator;
@property (nonatomic, strong) NSLayoutConstraint *containerHeightConstraint;
@end

@implementation CCWeatherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
    [self setupGestures];
    [self applyTheme];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onWeatherUpdated:)
                                                 name:@"CCWeatherDataUpdated"
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onPrefsChanged)
                                                 name:CCW_NOTIFY_CHANGED
                                               object:nil];

    // 初始加载天气
    self.weatherData = [CCWeatherManager sharedManager].currentData;
    if (!self.weatherData) {
        [self showLoading];
        [[CCWeatherManager sharedManager] refreshWeatherWithCompletion:^(CCWeatherData *data, NSError *error) {
            [self hideLoading];
            if (data) {
                self.weatherData = data;
                [self refreshUI];
            }
        }];
    }

    // 启动自动刷新
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];
    [[CCWeatherManager sharedManager] startAutoRefreshWithInterval:prefs.refreshInterval];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - UI Setup

- (void)setupUI {
    self.view.backgroundColor = [UIColor clearColor];

    self.containerView = [[UIView alloc] init];
    self.containerView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.containerView];

    [NSLayoutConstraint activateConstraints:@[
        [self.containerView.topAnchor constraintEqualToAnchor:self.view.topAnchor],
        [self.containerView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.containerView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.containerView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
    ]];

    // 天气图标
    self.weatherIcon = [[UIImageView alloc] init];
    self.weatherIcon.translatesAutoresizingMaskIntoConstraints = NO;
    self.weatherIcon.contentMode = UIViewContentModeScaleAspectFit;
    [self.containerView addSubview:self.weatherIcon];

    // 温度
    self.tempLabel = [[CCWRainbowLabel alloc] init];
    self.tempLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.tempLabel.font = [UIFont systemFontOfSize:48 weight:UIFontWeightThin];
    self.tempLabel.textAlignment = NSTextAlignmentCenter;
    self.tempLabel.text = @"--°";
    [self.containerView addSubview:self.tempLabel];

    // 城市
    self.cityLabel = [[CCWRainbowLabel alloc] init];
    self.cityLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.cityLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    self.cityLabel.textAlignment = NSTextAlignmentCenter;
    self.cityLabel.text = @"定位中...";
    [self.containerView addSubview:self.cityLabel];

    // 天气状况
    self.conditionLabel = [[CCWRainbowLabel alloc] init];
    self.conditionLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.conditionLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
    self.conditionLabel.textAlignment = NSTextAlignmentCenter;
    [self.containerView addSubview:self.conditionLabel];

    // 最高最低温
    self.highLowLabel = [[CCWRainbowLabel alloc] init];
    self.highLowLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.highLowLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
    self.highLowLabel.textAlignment = NSTextAlignmentCenter;
    [self.containerView addSubview:self.highLowLabel];

    // 降水概率
    self.precipLabel = [[CCWRainbowLabel alloc] init];
    self.precipLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.precipLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
    self.precipLabel.textAlignment = NSTextAlignmentCenter;
    [self.containerView addSubview:self.precipLabel];

    // 小时预报滚动视图
    self.hourlyScrollView = [[UIScrollView alloc] init];
    self.hourlyScrollView.translatesAutoresizingMaskIntoConstraints = NO;
    self.hourlyScrollView.showsHorizontalScrollIndicator = NO;
    self.hourlyScrollView.showsVerticalScrollIndicator = NO;
    [self.containerView addSubview:self.hourlyScrollView];

    self.hourlyStackView = [[UIStackView alloc] init];
    self.hourlyStackView.translatesAutoresizingMaskIntoConstraints = NO;
    self.hourlyStackView.axis = UILayoutConstraintAxisHorizontal;
    self.hourlyStackView.spacing = 12;
    self.hourlyStackView.alignment = UIStackViewAlignmentCenter;
    [self.hourlyScrollView addSubview:self.hourlyStackView];

    // 加载指示器
    self.loadingIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    self.loadingIndicator.translatesAutoresizingMaskIntoConstraints = NO;
    self.loadingIndicator.hidesWhenStopped = YES;
    [self.containerView addSubview:self.loadingIndicator];

    [NSLayoutConstraint activateConstraints:@[
        [self.hourlyStackView.topAnchor constraintEqualToAnchor:self.hourlyScrollView.topAnchor],
        [self.hourlyStackView.bottomAnchor constraintEqualToAnchor:self.hourlyScrollView.bottomAnchor],
        [self.hourlyStackView.leadingAnchor constraintEqualToAnchor:self.hourlyScrollView.leadingAnchor constant:8],
        [self.hourlyStackView.trailingAnchor constraintEqualToAnchor:self.hourlyScrollView.trailingAnchor constant:-8],
        [self.hourlyStackView.heightAnchor constraintEqualToAnchor:self.hourlyScrollView.heightAnchor],

        [self.loadingIndicator.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],
        [self.loadingIndicator.centerYAnchor constraintEqualToAnchor:self.containerView.centerYAnchor],
    ]];

    [self setupLayoutConstraints];
}

- (void)setupLayoutConstraints {
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];
    CGFloat iconSize = prefs.weatherIconSize;
    CGFloat spacing = prefs.contentSpacing;

    // 清除旧约束
    [self.containerView.constraints enumerateObjectsUsingBlock:^(NSLayoutConstraint *c, NSUInteger idx, BOOL *stop) {
        if (c.firstItem == self.weatherIcon || c.firstItem == self.tempLabel ||
            c.firstItem == self.cityLabel || c.firstItem == self.conditionLabel ||
            c.firstItem == self.highLowLabel || c.firstItem == self.precipLabel ||
            c.firstItem == self.hourlyScrollView) {
            c.active = NO;
        }
    }];

    BOOL isLarge = (prefs.moduleSize == CCWModuleSizeLarge) || self.expanded;
    BOOL isLandscape = (prefs.moduleSize == CCWModuleSizeLandscape);

    if (isLarge) {
        // 大尺寸 4x4 - 完整布局
        [NSLayoutConstraint activateConstraints:@[
            [self.weatherIcon.topAnchor constraintEqualToAnchor:self.containerView.topAnchor constant:spacing],
            [self.weatherIcon.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],
            [self.weatherIcon.widthAnchor constraintEqualToConstant:iconSize],
            [self.weatherIcon.heightAnchor constraintEqualToConstant:iconSize],

            [self.tempLabel.topAnchor constraintEqualToAnchor:self.weatherIcon.bottomAnchor constant:spacing/2],
            [self.tempLabel.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],

            [self.cityLabel.topAnchor constraintEqualToAnchor:self.tempLabel.bottomAnchor constant:spacing/2],
            [self.cityLabel.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],

            [self.conditionLabel.topAnchor constraintEqualToAnchor:self.cityLabel.bottomAnchor constant:2],
            [self.conditionLabel.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],

            [self.highLowLabel.topAnchor constraintEqualToAnchor:self.conditionLabel.bottomAnchor constant:2],
            [self.highLowLabel.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],

            [self.precipLabel.topAnchor constraintEqualToAnchor:self.highLowLabel.bottomAnchor constant:2],
            [self.precipLabel.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],

            [self.hourlyScrollView.topAnchor constraintEqualToAnchor:self.precipLabel.bottomAnchor constant:spacing],
            [self.hourlyScrollView.leadingAnchor constraintEqualToAnchor:self.containerView.leadingAnchor],
            [self.hourlyScrollView.trailingAnchor constraintEqualToAnchor:self.containerView.trailingAnchor],
            [self.hourlyScrollView.bottomAnchor constraintEqualToAnchor:self.containerView.bottomAnchor constant:-spacing],
            [self.hourlyScrollView.heightAnchor constraintEqualToConstant:60],
        ]];
    } else if (isLandscape) {
        // 横向 4x2 - 左右布局
        [NSLayoutConstraint activateConstraints:@[
            [self.weatherIcon.leadingAnchor constraintEqualToAnchor:self.containerView.leadingAnchor constant:spacing*2],
            [self.weatherIcon.centerYAnchor constraintEqualToAnchor:self.containerView.centerYAnchor],
            [self.weatherIcon.widthAnchor constraintEqualToConstant:iconSize * 0.8],
            [self.weatherIcon.heightAnchor constraintEqualToConstant:iconSize * 0.8],

            [self.tempLabel.leadingAnchor constraintEqualToAnchor:self.weatherIcon.trailingAnchor constant:spacing],
            [self.tempLabel.centerYAnchor constraintEqualToAnchor:self.containerView.centerYAnchor constant:-10],

            [self.cityLabel.leadingAnchor constraintEqualToAnchor:self.tempLabel.trailingAnchor constant:spacing],
            [self.cityLabel.centerYAnchor constraintEqualToAnchor:self.containerView.centerYAnchor constant:-10],

            [self.conditionLabel.leadingAnchor constraintEqualToAnchor:self.tempLabel.leadingAnchor],
            [self.conditionLabel.topAnchor constraintEqualToAnchor:self.tempLabel.bottomAnchor constant:2],

            [self.highLowLabel.leadingAnchor constraintEqualToAnchor:self.conditionLabel.trailingAnchor constant:spacing],
            [self.highLowLabel.centerYAnchor constraintEqualToAnchor:self.conditionLabel.centerYAnchor],

            [self.hourlyScrollView.bottomAnchor constraintEqualToAnchor:self.containerView.bottomAnchor constant:-4],
            [self.hourlyScrollView.leadingAnchor constraintEqualToAnchor:self.containerView.leadingAnchor],
            [self.hourlyScrollView.trailingAnchor constraintEqualToAnchor:self.containerView.trailingAnchor],
            [self.hourlyScrollView.heightAnchor constraintEqualToConstant:36],
        ]];
    } else {
        // 小尺寸 2x2 - 紧凑布局
        [NSLayoutConstraint activateConstraints:@[
            [self.weatherIcon.topAnchor constraintEqualToAnchor:self.containerView.topAnchor constant:spacing],
            [self.weatherIcon.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],
            [self.weatherIcon.widthAnchor constraintEqualToConstant:iconSize * 0.7],
            [self.weatherIcon.heightAnchor constraintEqualToConstant:iconSize * 0.7],

            [self.tempLabel.topAnchor constraintEqualToAnchor:self.weatherIcon.bottomAnchor constant:spacing/2],
            [self.tempLabel.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],

            [self.cityLabel.topAnchor constraintEqualToAnchor:self.tempLabel.bottomAnchor constant:2],
            [self.cityLabel.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],

            [self.conditionLabel.topAnchor constraintEqualToAnchor:self.cityLabel.bottomAnchor constant:2],
            [self.conditionLabel.centerXAnchor constraintEqualToAnchor:self.containerView.centerXAnchor],
        ]];
        self.hourlyScrollView.hidden = YES;
        self.highLowLabel.hidden = YES;
        self.precipLabel.hidden = YES;
    }
}

#pragma mark - 手势

- (void)setupGestures {
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
    singleTap.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:singleTap];

    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleDoubleTap:)];
    doubleTap.numberOfTapsRequired = 2;
    [self.view addGestureRecognizer:doubleTap];
    [singleTap requireGestureRecognizerToFail:doubleTap];

    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    longPress.minimumPressDuration = 0.5;
    [self.view addGestureRecognizer:longPress];

    UITapGestureRecognizer *twoFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTwoFingerTap:)];
    twoFingerTap.numberOfTouchesRequired = 2;
    [self.view addGestureRecognizer:twoFingerTap];
}

#pragma mark - 交互动作

- (void)handleSingleTap:(UITapGestureRecognizer *)tap {
    if (tap.state != UIGestureRecognizerStateEnded) return;
    [self executeAction:[CCWThemeManager sharedManager].singleTapAction];
}

- (void)handleDoubleTap:(UITapGestureRecognizer *)tap {
    if (tap.state != UIGestureRecognizerStateEnded) return;
    [self executeAction:[CCWThemeManager sharedManager].doubleTapAction];
}

- (void)handleLongPress:(UILongPressGestureRecognizer *)press {
    if (press.state != UIGestureRecognizerStateEnded) return;
    [self executeAction:[CCWThemeManager sharedManager].longPressAction];
}

- (void)handleTwoFingerTap:(UITapGestureRecognizer *)tap {
    if (tap.state != UIGestureRecognizerStateEnded) return;
    [self executeAction:[CCWThemeManager sharedManager].twoFingerTapAction];
}

- (void)executeAction:(CCWTapAction)action {
    switch (action) {
        case CCWTapActionToggle:
            [self toggleExpanded];
            break;
        case CCWTapActionRefresh:
            [self refreshWeather];
            break;
        case CCWTapActionSettings:
            [self openSettings];
            break;
        case CCWTapActionSwitchTheme:
            [self switchTheme];
            break;
        case CCWTapActionNone:
        default:
            break;
    }
}

- (void)toggleExpanded {
    self.expanded = !self.expanded;
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];

    if (prefs.animationEnabled) {
        [UIView animateWithDuration:0.3 animations:^{
            [self setupLayoutConstraints];
            [self.view layoutIfNeeded];
        }];
    } else {
        [self setupLayoutConstraints];
    }
    [self refreshUI];
}

- (void)refreshWeather {
    [self showLoading];
    [[CCWeatherManager sharedManager] refreshWeatherWithCompletion:^(CCWeatherData *data, NSError *error) {
        [self hideLoading];
        if (data) {
            self.weatherData = data;
            [self refreshUI];
        }
    }];
}

- (void)openSettings {
    // 通过URL scheme打开设置
    NSURL *url = [NSURL URLWithString:@"prefs:root=CCWeatherPrefs"];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    }
}

- (void)switchTheme {
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];
    NSInteger next = (prefs.theme + 1) % 8;
    NSMutableDictionary *allPrefs = [NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults] dictionaryForKey:CCW_PREF_DOMAIN] ?: @{}];
    allPrefs[kCCWThemeIndex] = @(next);
    [[NSUserDefaults standardUserDefaults] setObject:allPrefs forKey:CCW_PREF_DOMAIN];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:CCW_NOTIFY_CHANGED object:nil];
}

#pragma mark - 数据更新

- (void)onWeatherUpdated:(NSNotification *)note {
    self.weatherData = note.object;
    [self refreshUI];
}

- (void)onPrefsChanged {
    [[CCWThemeManager sharedManager] reloadPreferences];
    [self applyTheme];
    [self setupLayoutConstraints];
    [self refreshUI];
}

- (void)refreshUI {
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];

    if (!self.weatherData) {
        self.tempLabel.text = @"--°";
        self.cityLabel.text = @"加载中...";
        return;
    }

    // 图标
    NSString *iconPath = [[NSBundle mainBundle] pathForResource:self.weatherData.iconName ofType:@"png"];
    if (iconPath) {
        self.weatherIcon.image = [UIImage imageWithContentsOfFile:iconPath];
    }

    // 温度
    NSInteger unit = prefs.tempUnit;
    self.tempLabel.text = [CCWeatherManager temperatureString:self.weatherData.currentTemp unit:unit];
    self.tempLabel.font = [UIFont systemFontOfSize:prefs.tempFontSize weight:UIFontWeightThin];

    // 城市
    self.cityLabel.text = prefs.showCity ? self.weatherData.city : @"";
    self.cityLabel.font = [UIFont systemFontOfSize:prefs.cityFontSize weight:UIFontWeightMedium];
    self.cityLabel.hidden = !prefs.showCity;

    // 天气状况
    self.conditionLabel.text = prefs.showCondition ? self.weatherData.condition : @"";
    self.conditionLabel.font = [UIFont systemFontOfSize:prefs.hourlyFontSize weight:UIFontWeightRegular];
    self.conditionLabel.hidden = !prefs.showCondition;

    // 最高最低温
    if (prefs.showHighLow) {
        NSString *high = [CCWeatherManager temperatureString:self.weatherData.highTemp unit:unit];
        NSString *low = [CCWeatherManager temperatureString:self.weatherData.lowTemp unit:unit];
        self.highLowLabel.text = [NSString stringWithFormat:@"%@ / %@", high, low];
    }
    self.highLowLabel.hidden = !prefs.showHighLow;

    // 降水概率
    if (prefs.showPrecipitation && self.weatherData.precipitation > 0) {
        self.precipLabel.text = [NSString stringWithFormat:@"降水 %ld%%", (long)self.weatherData.precipitation];
    }
    self.precipLabel.hidden = !prefs.showPrecipitation;

    // 小时预报
    [self setupHourlyForecast];

    // 应用颜色主题
    [self applyColorsToLabels];
}

- (void)setupHourlyForecast {
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];

    // 清除旧的
    for (UIView *sub in self.hourlyStackView.arrangedSubviews) {
        [self.hourlyStackView removeArrangedSubview:sub];
        [sub removeFromSuperview];
    }

    if (!prefs.showHourly || !self.weatherData.hourlyForecasts.count) {
        self.hourlyScrollView.hidden = YES;
        return;
    }
    self.hourlyScrollView.hidden = NO;

    NSInteger maxCount = prefs.show24Hour ? 24 : 6;
    NSInteger count = MIN(maxCount, self.weatherData.hourlyForecasts.count);

    for (NSInteger i = 0; i < count; i++) {
        CCWHourlyForecast *f = self.weatherData.hourlyForecasts[i];
        UIView *itemView = [self createHourlyItem:f];
        [self.hourlyStackView addArrangedSubview:itemView];
    }
}

- (UIView *)createHourlyItem:(CCWHourlyForecast *)forecast {
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];
    UIView *item = [[UIView alloc] init];
    item.translatesAutoresizingMaskIntoConstraints = NO;

    CCWRainbowLabel *timeLabel = [[CCWRainbowLabel alloc] init];
    timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    timeLabel.font = [UIFont systemFontOfSize:prefs.hourlyFontSize - 2];
    timeLabel.textAlignment = NSTextAlignmentCenter;
    timeLabel.text = forecast.time;
    timeLabel.solidColor = prefs.hourlyColor;
    timeLabel.rainbowEnabled = prefs.rainbowEnabled;
    timeLabel.rainbowAnimated = prefs.rainbowAnimated;
    timeLabel.rainbowSpeed = prefs.rainbowSpeed;
    timeLabel.gradientDirection = prefs.gradientDirection;
    [timeLabel applyTheme];
    [item addSubview:timeLabel];

    UIImageView *icon = [[UIImageView alloc] init];
    icon.translatesAutoresizingMaskIntoConstraints = NO;
    icon.contentMode = UIViewContentModeScaleAspectFit;
    NSString *iconPath = [[NSBundle mainBundle] pathForResource:forecast.iconName ofType:@"png"];
    if (iconPath) icon.image = [UIImage imageWithContentsOfFile:iconPath];
    [item addSubview:icon];

    CCWRainbowLabel *tempLabel = [[CCWRainbowLabel alloc] init];
    tempLabel.translatesAutoresizingMaskIntoConstraints = NO;
    tempLabel.font = [UIFont systemFontOfSize:prefs.hourlyFontSize weight:UIFontWeightMedium];
    tempLabel.textAlignment = NSTextAlignmentCenter;
    tempLabel.text = [CCWeatherManager temperatureString:forecast.temperature unit:prefs.tempUnit];
    tempLabel.solidColor = prefs.hourlyColor;
    tempLabel.rainbowEnabled = prefs.rainbowEnabled;
    tempLabel.rainbowAnimated = prefs.rainbowAnimated;
    tempLabel.rainbowSpeed = prefs.rainbowSpeed;
    tempLabel.gradientDirection = prefs.gradientDirection;
    [tempLabel applyTheme];
    [item addSubview:tempLabel];

    [NSLayoutConstraint activateConstraints:@[
        [timeLabel.topAnchor constraintEqualToAnchor:item.topAnchor],
        [timeLabel.centerXAnchor constraintEqualToAnchor:item.centerXAnchor],
        [timeLabel.widthAnchor constraintEqualToConstant:40],

        [icon.topAnchor constraintEqualToAnchor:timeLabel.bottomAnchor constant:2],
        [icon.centerXAnchor constraintEqualToAnchor:item.centerXAnchor],
        [icon.widthAnchor constraintEqualToConstant:24],
        [icon.heightAnchor constraintEqualToConstant:24],

        [tempLabel.topAnchor constraintEqualToAnchor:icon.bottomAnchor constant:2],
        [tempLabel.centerXAnchor constraintEqualToAnchor:item.centerXAnchor],
        [tempLabel.bottomAnchor constraintEqualToAnchor:item.bottomAnchor],
        [tempLabel.widthAnchor constraintEqualToConstant:40],
    ]];

    return item;
}

- (void)applyColorsToLabels {
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];

    NSArray *labels = @[
        @{@"label": self.tempLabel, @"color": prefs.tempColor},
        @{@"label": self.cityLabel, @"color": prefs.cityColor},
        @{@"label": self.conditionLabel, @"color": prefs.statusColor},
        @{@"label": self.highLowLabel, @"color": prefs.statusColor},
        @{@"label": self.precipLabel, @"color": prefs.statusColor},
    ];

    for (NSDictionary *d in labels) {
        CCWRainbowLabel *label = d[@"label"];
        label.solidColor = d[@"color"];
        label.rainbowEnabled = prefs.rainbowEnabled;
        label.rainbowAnimated = prefs.rainbowAnimated;
        label.rainbowSpeed = prefs.rainbowSpeed;
        label.gradientDirection = prefs.gradientDirection;
        [label applyTheme];
    }
}

#pragma mark - 主题

- (void)applyTheme {
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];
    [prefs applyThemeToView:self.containerView];
    [self applyColorsToLabels];

    // 字体大小
    self.tempLabel.font = [UIFont systemFontOfSize:prefs.tempFontSize weight:UIFontWeightThin];
    self.cityLabel.font = [UIFont systemFontOfSize:prefs.cityFontSize weight:UIFontWeightMedium];
    self.conditionLabel.font = [UIFont systemFontOfSize:prefs.hourlyFontSize weight:UIFontWeightRegular];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    [self applyTheme];
}

#pragma mark - Loading

- (void)showLoading {
    [self.loadingIndicator startAnimating];
}

- (void)hideLoading {
    [self.loadingIndicator stopAnimating];
}

#pragma mark - CCUIContentModuleContentViewController

- (CCUILayoutSize)preferredContentSize {
    CCWThemeManager *prefs = [CCWThemeManager sharedManager];
    switch (prefs.moduleSize) {
        case CCWModuleSizeSmall:
            return (CCUILayoutSize){2, 2};
        case CCWModuleSizeLandscape:
            return (CCUILayoutSize){4, 2};
        case CCWModuleSizeLarge:
            return (CCUILayoutSize){4, 4};
        default:
            return (CCUILayoutSize){2, 2};
    }
}

@end
