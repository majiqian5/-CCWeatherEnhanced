//
//  CCWeatherData.h
//  天气数据模型
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CCWHourlyForecast : NSObject
@property (nonatomic, copy) NSString *time;          // 小时，如 "14:00"
@property (nonatomic, assign) NSInteger temperature; // 温度
@property (nonatomic, copy) NSString *condition;     // 天气状况描述
@property (nonatomic, copy) NSString *iconName;      // 图标文件名
@property (nonatomic, assign) NSInteger precipitation; // 降水概率 0~100
@end

@interface CCWeatherData : NSObject
@property (nonatomic, copy) NSString *city;
@property (nonatomic, assign) NSInteger currentTemp;
@property (nonatomic, assign) NSInteger highTemp;
@property (nonatomic, assign) NSInteger lowTemp;
@property (nonatomic, copy) NSString *condition;     // 天气状况
@property (nonatomic, copy) NSString *iconName;      // 当前天气图标
@property (nonatomic, assign) NSInteger precipitation; // 降水概率
@property (nonatomic, strong) NSArray<CCWHourlyForecast *> *hourlyForecasts;
@property (nonatomic, strong) NSDate *updateTime;
@property (nonatomic, assign) BOOL isLoading;
@property (nonatomic, copy) NSString *errorMessage;
@end

NS_ASSUME_NONNULL_END
