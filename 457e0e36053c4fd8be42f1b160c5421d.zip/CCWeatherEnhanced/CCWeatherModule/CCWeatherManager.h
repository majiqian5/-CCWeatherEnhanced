//
//  CCWeatherManager.h
//  天气数据获取与管理
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "CCWeatherData.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^CCWeatherCompletion)(CCWeatherData * _Nullable data, NSError * _Nullable error);

@interface CCWeatherManager : NSObject <CLLocationManagerDelegate>

+ (instancetype)sharedManager;

@property (nonatomic, strong) CCWeatherData *currentData;
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, copy) NSString *currentCity;
@property (nonatomic, assign) CLLocationCoordinate2D currentCoordinate;

// 刷新天气
- (void)refreshWeatherWithCompletion:(nullable CCWeatherCompletion)completion;

// 定时刷新
- (void)startAutoRefreshWithInterval:(NSInteger)minutes;
- (void)stopAutoRefresh;

// 温度转换
+ (NSInteger)convertCelsius:(NSInteger)c toUnit:(NSInteger)unit; // 0=摄氏 1=华氏
+ (NSString *)temperatureString:(NSInteger)temp unit:(NSInteger)unit;

// 天气状况到图标名映射
+ (NSString *)iconNameForCondition:(NSString *)condition isDay:(BOOL)isDay;

@end

NS_ASSUME_NONNULL_END
