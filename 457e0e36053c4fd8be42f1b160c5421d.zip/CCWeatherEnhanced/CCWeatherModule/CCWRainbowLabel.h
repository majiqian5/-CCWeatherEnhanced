//
//  CCWRainbowLabel.h
//  彩虹渐变文字标签，支持静态渐变和动态流动
//

#import <UIKit/UIKit.h>
#import "CCWeatherConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCWRainbowLabel : UILabel

@property (nonatomic, assign) BOOL rainbowEnabled;
@property (nonatomic, assign) BOOL rainbowAnimated;
@property (nonatomic, assign) CGFloat rainbowSpeed;
@property (nonatomic, assign) CCWGradientDirection gradientDirection;
@property (nonatomic, strong) UIColor *solidColor;

// 开始/停止动画
- (void)startAnimation;
- (void)stopAnimation;

// 应用主题配置
- (void)applyTheme;

@end

NS_ASSUME_NONNULL_END
