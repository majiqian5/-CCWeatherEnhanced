//
//  CCWThemeManager.h
//  主题与偏好管理
//

#import <UIKit/UIKit.h>
#import "CCWeatherConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface CCWThemeManager : NSObject

+ (instancetype)sharedManager;

// 重新加载偏好
- (void)reloadPreferences;

// 外观
@property (nonatomic, assign) CCWTheme theme;
@property (nonatomic, assign) CCWBackgroundStyle backgroundStyle;
@property (nonatomic, strong) UIColor *backgroundColor;
@property (nonatomic, assign) CGFloat cornerRadius;
@property (nonatomic, assign) CGFloat moduleAlpha;
@property (nonatomic, assign) BOOL borderEnabled;
@property (nonatomic, assign) CGFloat borderWidth;
@property (nonatomic, strong) UIColor *borderColor;
@property (nonatomic, assign) BOOL shadowEnabled;
@property (nonatomic, assign) CGFloat shadowRadius;
@property (nonatomic, assign) CGFloat shadowOpacity;

// 字体大小
@property (nonatomic, assign) CGFloat weatherIconSize;
@property (nonatomic, assign) CGFloat tempFontSize;
@property (nonatomic, assign) CGFloat cityFontSize;
@property (nonatomic, assign) CGFloat hourlyFontSize;

// 颜色
@property (nonatomic, strong) UIColor *tempColor;
@property (nonatomic, strong) UIColor *cityColor;
@property (nonatomic, strong) UIColor *statusColor;
@property (nonatomic, strong) UIColor *hourlyColor;
@property (nonatomic, assign) BOOL rainbowEnabled;
@property (nonatomic, assign) BOOL rainbowAnimated;
@property (nonatomic, assign) CGFloat rainbowSpeed;
@property (nonatomic, assign) CCWGradientDirection gradientDirection;

// 尺寸
@property (nonatomic, assign) CCWModuleSize moduleSize;
@property (nonatomic, assign) BOOL dynamicSize;

// 天气内容
@property (nonatomic, assign) BOOL showHighLow;
@property (nonatomic, assign) BOOL showCondition;
@property (nonatomic, assign) BOOL showPrecipitation;
@property (nonatomic, assign) BOOL showCity;
@property (nonatomic, assign) BOOL showHourly;
@property (nonatomic, assign) BOOL show24Hour;
@property (nonatomic, assign) NSInteger weatherIconStyle;
@property (nonatomic, assign) NSInteger tempUnit; // 0=摄氏 1=华氏
@property (nonatomic, assign) BOOL autoLocation;
@property (nonatomic, copy) NSString *customCity;
@property (nonatomic, assign) CGFloat customLatitude;
@property (nonatomic, assign) CGFloat customLongitude;
@property (nonatomic, assign) NSInteger refreshInterval;

// 交互
@property (nonatomic, assign) CCWTapAction singleTapAction;
@property (nonatomic, assign) CCWTapAction doubleTapAction;
@property (nonatomic, assign) CCWTapAction longPressAction;
@property (nonatomic, assign) CCWTapAction twoFingerTapAction;
@property (nonatomic, assign) BOOL expandedMode;

// 布局
@property (nonatomic, assign) CGFloat contentSpacing;
@property (nonatomic, assign) NSInteger contentAlignment;

// 高级
@property (nonatomic, assign) BOOL animationEnabled;
@property (nonatomic, assign) BOOL debugLog;

// 工具方法
- (UIColor *)colorFromDict:(NSDictionary *)dict defaultColor:(UIColor *)defaultColor;
- (NSDictionary *)dictFromColor:(UIColor *)color;
- (void)applyThemeToView:(UIView *)view;
- (UIColor *)primaryTextColor; // 根据主题返回主文字色

@end

NS_ASSUME_NONNULL_END
