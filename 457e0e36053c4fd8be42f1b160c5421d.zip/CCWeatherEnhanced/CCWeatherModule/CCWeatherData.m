//
//  CCWeatherData.m
//

#import "CCWeatherData.h"

@implementation CCWHourlyForecast
@end

@implementation CCWeatherData
@end
