//
//  CCWThemeManager.m
//

#import "CCWThemeManager.h"

@implementation CCWThemeManager

+ (instancetype)sharedManager {
    static CCWThemeManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[CCWThemeManager alloc] init];
        [instance reloadPreferences];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(reloadPreferences)
                                                     name:CCW_NOTIFY_CHANGED
                                                   object:nil];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (NSDictionary *)prefs {
    return [[NSUserDefaults standardUserDefaults] dictionaryForKey:CCW_PREF_DOMAIN] ?: @{};
}

- (void)reloadPreferences {
    NSDictionary *p = [self prefs];

    // 外观
    self.theme = [p[kCCWThemeIndex] integerValue];
    self.backgroundStyle = [p[kCCWBackgroundStyle] integerValue];
    self.backgroundColor = [self colorFromDict:p[kCCWBackgroundColor] defaultColor:[UIColor colorWithWhite:0.1 alpha:0.7]];
    self.cornerRadius = [p[kCCWCornerRadius] floatValue] ?: 16;
    self.moduleAlpha = [p[kCCWModuleAlpha] floatValue] ?: 0.85;
    self.borderEnabled = [p[kCCWBorderEnabled] boolValue];
    self.borderWidth = [p[kCCWBorderWidth] floatValue] ?: 1;
    self.borderColor = [self colorFromDict:p[kCCWBorderColor] defaultColor:[UIColor whiteColor]];
    self.shadowEnabled = [p[kCCWShadowEnabled] boolValue];
    self.shadowRadius = [p[kCCWShadowRadius] floatValue] ?: 8;
    self.shadowOpacity = [p[kCCWShadowOpacity] floatValue] ?: 0.3;

    // 字体大小
    self.weatherIconSize = [p[kCCWWeatherIconSize] floatValue] ?: 50;
    self.tempFontSize = [p[kCCWTempFontSize] floatValue] ?: 48;
    self.cityFontSize = [p[kCCWCityFontSize] floatValue] ?: 16;
    self.hourlyFontSize = [p[kCCWHourlyFontSize] floatValue] ?: 12;

    // 颜色
    self.tempColor = [self colorFromDict:p[kCCWTempColor] defaultColor:[UIColor whiteColor]];
    self.cityColor = [self colorFromDict:p[kCCWCityColor] defaultColor:[UIColor whiteColor]];
    self.statusColor = [self colorFromDict:p[kCCWStatusColor] defaultColor:[UIColor whiteColor]];
    self.hourlyColor = [self colorFromDict:p[kCCWHourlyColor] defaultColor:[UIColor whiteColor]];
    self.rainbowEnabled = [p[kCCWRainbowEnabled] boolValue];
    self.rainbowAnimated = [p[kCCWRainbowAnimated] boolValue];
    self.rainbowSpeed = [p[kCCWRainbowSpeed] floatValue] ?: 1.0;
    self.gradientDirection = [p[kCCWGradientDirection] integerValue];

    // 尺寸
    self.moduleSize = [p[kCCWModuleSize] integerValue];
    self.dynamicSize = [p[kCCWDynamicSize] boolValue];

    // 天气内容
    self.showHighLow = [p[kCCWShowHighLow] boolValue] ?: YES;
    self.showCondition = [p[kCCWShowCondition] boolValue] ?: YES;
    self.showPrecipitation = [p[kCCWShowPrecipitation] boolValue] ?: YES;
    self.showCity = [p[kCCWShowCity] boolValue] ?: YES;
    self.showHourly = [p[kCCWShowHourly] boolValue] ?: YES;
    self.show24Hour = [p[kCCWShow24Hour] boolValue];
    self.weatherIconStyle = [p[kCCWWeatherIconStyle] integerValue];
    self.tempUnit = [p[kCCWTempUnit] integerValue];
    self.autoLocation = [p[kCCWAutoLocation] boolValue] ?: YES;
    self.customCity = p[kCCWCustomCity] ?: @"";
    self.customLatitude = [p[kCCWCustomLatitude] floatValue];
    self.customLongitude = [p[kCCWCustomLongitude] floatValue];
    self.refreshInterval = [p[kCCWRefreshInterval] integerValue] ?: 15;

    // 交互
    self.singleTapAction = [p[kCCWSingleTapAction] integerValue];
    self.doubleTapAction = [p[kCCWDoubleTapAction] integerValue] ?: 1;
    self.longPressAction = [p[kCCWLongPressAction] integerValue] ?: 2;
    self.twoFingerTapAction = [p[kCCWTwoFingerTapAction] integerValue] ?: 3;
    self.expandedMode = [p[kCCWExpandedMode] boolValue];

    // 布局
    self.contentSpacing = [p[kCCWContentSpacing] floatValue] ?: 8;
    self.contentAlignment = [p[kCCWContentAlignment] integerValue] ?: 1;

    // 高级
    self.animationEnabled = [p[kCCWAnimationEnabled] boolValue] ?: YES;
    self.debugLog = [p[kCCWDebugLog] boolValue];
}

- (UIColor *)colorFromDict:(NSDictionary *)dict defaultColor:(UIColor *)defaultColor {
    if (!dict || ![dict isKindOfClass:[NSDictionary class]]) return defaultColor;
    CGFloat r = [dict[@"r"] floatValue] / 255.0;
    CGFloat g = [dict[@"g"] floatValue] / 255.0;
    CGFloat b = [dict[@"b"] floatValue] / 255.0;
    CGFloat a = dict[@"a"] ? [dict[@"a"] floatValue] : 1.0;
    return [UIColor colorWithRed:r green:g blue:b alpha:a];
}

- (NSDictionary *)dictFromColor:(UIColor *)color {
    CGFloat r, g, b, a;
    [color getRed:&r green:&g blue:&b alpha:&a];
    return @{@"r": @(r*255), @"g": @(g*255), @"b": @(b*255), @"a": @(a)};
}

- (UIColor *)primaryTextColor {
    switch (self.theme) {
        case CCWThemeLight:
        case CCWThemeSunset:
            return [UIColor blackColor];
        case CCWThemeOcean:
        case CCWThemeForest:
        case CCWThemePurple:
        case CCWThemeDark:
        case CCWThemeMonochrome:
            return [UIColor whiteColor];
        case CCWThemeSystem:
        default:
            return [UIColor whiteColor];
    }
}

- (void)applyThemeToView:(UIView *)view {
    CCWThemeManager *m = [CCWThemeManager sharedManager];

    // 背景
    for (UIView *sub in view.subviews) {
        if ([sub isKindOfClass:[UIVisualEffectView class]]) {
            [sub removeFromSuperview];
        }
    }

    if (m.backgroundStyle == CCWBackgroundStyleGlass) {
        UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        UIVisualEffectView *blurView = [[UIVisualEffectView alloc] initWithEffect:blur];
        blurView.frame = view.bounds;
        blurView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        blurView.alpha = m.moduleAlpha;
        [view insertSubview:blurView atIndex:0];
    } else {
        view.backgroundColor = [m.backgroundColor colorWithAlphaComponent:m.moduleAlpha];
    }

    // 圆角
    view.layer.cornerRadius = m.cornerRadius;
    view.clipsToBounds = YES;

    // 边框
    if (m.borderEnabled) {
        view.layer.borderWidth = m.borderWidth;
        view.layer.borderColor = m.borderColor.CGColor;
    } else {
        view.layer.borderWidth = 0;
    }

    // 阴影
    if (m.shadowEnabled) {
        view.layer.shadowColor = [UIColor blackColor].CGColor;
        view.layer.shadowRadius = m.shadowRadius;
        view.layer.shadowOpacity = m.shadowOpacity;
        view.layer.shadowOffset = CGSizeMake(0, 2);
        view.clipsToBounds = NO;
    }
}

@end
