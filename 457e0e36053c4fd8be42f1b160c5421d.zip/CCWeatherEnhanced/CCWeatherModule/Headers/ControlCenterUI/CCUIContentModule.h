#import <UIKit/UIKit.h>

typedef struct {
    NSUInteger width;
    NSUInteger height;
} CCUILayoutSize;

NS_INLINE CCUILayoutSize CCUILayoutSizeMake(NSUInteger width, NSUInteger height) {
    CCUILayoutSize s; s.width = width; s.height = height; return s;
}

@protocol CCUIContentModuleContentViewController <NSObject>
@optional
- (CCUILayoutSize)preferredContentSize;
@property (nonatomic, readonly) BOOL providesOwnPlatter;
@property (nonatomic, weak) id contentModuleDelegate;
@end

@protocol CCUIContentModule <NSObject>
@property (nonatomic, readonly) UIViewController<CCUIContentModuleContentViewController> *contentViewController;
@optional
@property (nonatomic, readonly) UIViewController *backgroundViewController;
- (void)setContentModuleRunning:(BOOL)running;
- (void)dismissControlCenterAnimated:(BOOL)animated;
@end
