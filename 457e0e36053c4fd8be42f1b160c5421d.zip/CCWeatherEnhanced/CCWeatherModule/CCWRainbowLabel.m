//
//  CCWRainbowLabel.m
//

#import "CCWRainbowLabel.h"

@interface CCWRainbowLabel ()
@property (nonatomic, strong) CAGradientLayer *gradientLayer;
@property (nonatomic, strong) CADisplayLink *displayLink;
@property (nonatomic, assign) CGFloat hueOffset;
@end

@implementation CCWRainbowLabel

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _solidColor = [UIColor whiteColor];
        _rainbowSpeed = 1.0;
    }
    return self;
}

- (void)applyTheme {
    if (self.rainbowEnabled) {
        [self setupGradient];
        if (self.rainbowAnimated) {
            [self startAnimation];
        } else {
            [self stopAnimation];
            [self updateGradientColors];
        }
    } else {
        [self stopAnimation];
        self.textColor = self.solidColor;
        if (self.gradientLayer) {
            [self.gradientLayer removeFromSuperlayer];
            self.gradientLayer = nil;
        }
    }
}

- (void)setupGradient {
    if (!self.gradientLayer) {
        self.gradientLayer = [CAGradientLayer layer];
        self.gradientLayer.frame = self.bounds;
        [self updateGradientDirection];
        [self.layer addSublayer:self.gradientLayer];
    }
    [self updateGradientColors];
    [self updateGradientDirection];
}

- (void)updateGradientDirection {
    switch (self.gradientDirection) {
        case CCWGradientHorizontal:
            self.gradientLayer.startPoint = CGPointMake(0, 0.5);
            self.gradientLayer.endPoint = CGPointMake(1, 0.5);
            break;
        case CCWGradientVertical:
            self.gradientLayer.startPoint = CGPointMake(0.5, 0);
            self.gradientLayer.endPoint = CGPointMake(0.5, 1);
            break;
        case CCWGradientDiagonal:
            self.gradientLayer.startPoint = CGPointMake(0, 0);
            self.gradientLayer.endPoint = CGPointMake(1, 1);
            break;
    }
}

- (void)updateGradientColors {
    NSMutableArray *colors = [NSMutableArray array];
    NSInteger count = 7;
    for (NSInteger i = 0; i < count; i++) {
        CGFloat hue = (i / (CGFloat)count + self.hueOffset) ;
        if (hue > 1.0) hue -= 1.0;
        UIColor *c = [UIColor colorWithHue:hue saturation:0.8 brightness:1.0 alpha:1.0];
        [colors addObject:(id)c.CGColor];
    }
    // 让渐变循环
    [colors addObject:(id)[UIColor colorWithHue:self.hueOffset saturation:0.8 brightness:1.0 alpha:1.0].CGColor];
    self.gradientLayer.colors = colors;
}

- (void)startAnimation {
    if (self.displayLink) return;
    self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(animateTick:)];
    [self.displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)stopAnimation {
    [self.displayLink invalidate];
    self.displayLink = nil;
}

- (void)animateTick:(CADisplayLink *)link {
    self.hueOffset += 0.002 * self.rainbowSpeed;
    if (self.hueOffset > 1.0) self.hueOffset -= 1.0;
    [self updateGradientColors];
}

- (void)setText:(NSString *)text {
    [super setText:text];
    if (self.rainbowEnabled) {
        [self setNeedsLayout];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.gradientLayer) {
        self.gradientLayer.frame = self.bounds;
        // 用文字作为mask
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, 0);
        NSDictionary *attrs = @{NSFontAttributeName: self.font,
                                NSForegroundColorAttributeName: [UIColor blackColor]};
        [self.text drawInRect:self.bounds withAttributes:attrs];
        UIImage *textImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();

        CALayer *maskLayer = [CALayer layer];
        maskLayer.contents = (id)textImage.CGImage;
        maskLayer.frame = self.bounds;
        self.gradientLayer.mask = maskLayer;
    }
}

- (void)dealloc {
    [self stopAnimation];
}

@end
